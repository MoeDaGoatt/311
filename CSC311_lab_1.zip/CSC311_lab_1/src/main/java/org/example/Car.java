package org.example;

public class Car extends Vehicle{
    protected String brand;
    public Car(int numberOfWheels,String color, float engineSize, String fuelType, String brand ) {
        this.numberOfWheels = numberOfWheels;
        this.color = color;
        this.engineSize= engineSize;
        this.fuelType = fuelType;
        this.brand = brand;
    }


    static void honk() {
        System.out.println("Honk! Honk!");
    }

    void displayInfo() {
        System.out.println(numberOfWheels + " " +color + " " + engineSize + " " + fuelType + " "+ brand);
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getBrand() {
        return brand;
    }
}


