package org.example;

public class Vehicle {
    protected int numberOfWheels;
    protected String color;
    protected float engineSize;
    protected String fuelType;

    public Vehicle() {
        numberOfWheels = 4;
        color = "silver";
        engineSize = 2.5F;
        fuelType = "gasoline";
    }
    public Vehicle(int n, String c, float e, String ft) {
        this.numberOfWheels = n;
        this.color = c;
        this.engineSize = e;
        this.fuelType = ft;
    }

    public void setEngineSize(float engineSize) {
        this.engineSize = engineSize;
    }

    public float getEngineSize() {
        return engineSize;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setNumberOfWheels(int numberOfWheels) {
        this.numberOfWheels = numberOfWheels;
    }

    public int getNumberOfWheels() {
        return numberOfWheels;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getColor() {
        return color;
    }
}



